import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import './SingIn.css'

function SingIn () {
    return (
        <>
            <h1 className='tittle'>INICIA SESIÓN CON NOSOTROS</h1>
            <p className="description">“Descubre mundos entre páginas: ¡Bienvenido a nuestra comunidad literaria!”</p>
            <div className="input-container">
                <input type="text" placeholder='Nombre'/>
                <input type="password" placeholder='Contraseña'/>
                <button type='submit'>INICIAR</button>
            </div>
        </>
    )
}

export default SingIn;