function AboutUs () {
    return (
        <>
            <h1>Hola desde About Us</h1>
        </>
    )
}

export default AboutUs;